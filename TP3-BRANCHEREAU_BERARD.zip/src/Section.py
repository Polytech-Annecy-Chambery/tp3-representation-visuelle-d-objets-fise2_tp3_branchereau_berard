# -*- coding: utf-8 -*-
"""
Created on Thu Nov 16 19:47:50 2017

@author: lfoul
"""
import OpenGL.GL as gl

class Section:
    # Constructor
    def __init__(self, parameters = {}) :  
        # Parameters
        # position: position of the wall 
        # width: width of the wall - mandatory
        # height: height of the wall - mandatory
        # thickness: thickness of the wall
        # color: color of the wall        

        # Sets the parameters
        self.parameters = parameters
        
        # Sets the default parameters
        if 'position' not in self.parameters:
            self.parameters['position'] = [0, 0, 0]        
        if 'width' not in self.parameters:
            raise Exception('Parameter "width" required.')   
        if 'height' not in self.parameters:
            raise Exception('Parameter "height" required.')   
        if 'orientation' not in self.parameters:
            self.parameters['orientation'] = 0              
        if 'thickness' not in self.parameters:
            self.parameters['thickness'] = 0.2    
        if 'color' not in self.parameters:
            self.parameters['color'] = [0.5, 0.5, 0.5]       
        if 'edges' not in self.parameters:
            self.parameters['edges'] = False       
            
        # Objects list
        self.objects = []

        # Generates the wall from parameters
        self.generate()   
        
    # Getter
    def getParameter(self, parameterKey):
        return self.parameters[parameterKey]
    
    # Setter
    def setParameter(self, parameterKey, parameterValue):
        self.parameters[parameterKey] = parameterValue
        return self     

    # Defines the vertices and faces 
    def generate(self):
        self.vertices = [ 
                [0, 0, 0 ], 
                [0, 0, self.parameters['height']], 
                [self.parameters['width'], 0, self.parameters['height']],
                [self.parameters['width'], 0, 0],
                [self.parameters['width'], self.parameters['thickness'], 0],
                [self.parameters['width'], self.parameters['thickness'], self.parameters['height']],
                [0, self.parameters['thickness'], self.parameters['height']],
                [0, self.parameters['thickness'], 0]
                ]
        self.faces = [
                [0, 1, 2, 3],
                [2, 3, 4, 5],
                [4, 5, 6, 7],
                [6, 7, 0, 1],
                [1, 2, 5, 6],
                [0, 3, 4, 7]
                ]   
    # Checks if the opening can be created for the object x
    def canCreateOpening(self, x):

        #verif position
        verif_position =[0,0,0]
        for i in range(3):
          if i == 0 and x.parameters['position'][i] >= self.parameters['position'][i] and x.parameters['position'][i] <= self.parameters['width'] :
            verif_position[i] = 1

          if i == 1 and x.parameters['position'][i] >= self.parameters['position'][i] and x.parameters['position'][i] <= self.parameters['thickness'] :
            verif_position[i] = 1

          if i == 2 and x.parameters['position'][i] >= self.parameters['position'][i] and x.parameters['position'][i] <= self.parameters['height'] :
            verif_position[i] = 1
        
        #verif dimension
        verif_dimension=[0,0,0]
        for i in range(3):

          if i == 0 and x.parameters['width'] < (self.parameters['width']-x.parameters['position'][i]):
            verif_dimension[i] = 1

          if i == 1 and x.parameters['thickness'] <= (self.parameters['thickness']-x.parameters['position'][i]):
            verif_dimension[i] = 1

          if i == 2 and x.parameters['height'] < (self.parameters['height']-x.parameters['position'][i]):
            verif_dimension[i] = 1

        print(verif_position)
        print(verif_dimension)

        return(verif_position == [1,1,1] and verif_dimension == [1,1,1])
        
    # Creates the new sections for the object x
    def createNewSections(self, x):
        # A compléter en remplaçant pass par votre code
        pass              
        
    # Draws the edges
    def drawEdges(self):
      if self.parameters['edges'] == True:
        facteura=0.5 #facteur d'assombrissement
        gl.glPushMatrix()
        gl.glTranslatef(self.parameters['position'][0],self.parameters['position'][1],self.parameters['position'][2])
        gl.glPolygonMode(gl.GL_FRONT_AND_BACK, gl.GL_LINE) 
        gl.glBegin(gl.GL_QUADS) # Tracé d’un quadrilatère
        gl.glColor3fv([0.5*facteura, 0.5*facteura, 0.5*facteura]) # Couleur gris foncé
        
        for f in self.faces:
          for x in f:
            gl.glVertex3fv (self.vertices[x])
        gl.glEnd()
        gl.glPopMatrix()
                    
    # Draws the faces
    def draw(self):
        gl.glPushMatrix()
        gl.glTranslatef(self.parameters['position'][0],self.parameters['position'][1],self.parameters['position'][2])
        gl.glPolygonMode(gl.GL_FRONT_AND_BACK, gl.GL_FILL) # on trace les faces : GL_FILL
        gl.glBegin(gl.GL_QUADS) # Tracé d’un quadrilatère
        gl.glColor3fv([0.5,0.5, 0.5]) # Couleur gris moyen
        
        for f in self.faces:
          for x in f:
            gl.glVertex3fv (self.vertices[x])
        gl.glEnd()
        gl.glPopMatrix()
  